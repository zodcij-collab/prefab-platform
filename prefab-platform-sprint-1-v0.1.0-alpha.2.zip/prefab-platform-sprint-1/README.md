# PREFAB.LV Corporate Platform

First runnable foundation of the PREFAB.LV corporate website and future private portal.

**Release:** `v0.1.0-alpha.2`

## Included

- Next.js App Router and TypeScript
- Responsive Scandinavian Construction homepage
- Mobile navigation
- PREFAB.LV brand asset
- Company, services, projects, careers and contact sections
- Private portal login placeholder
- SEO metadata, robots and sitemap
- ESLint, typecheck and production-build scripts
- GitHub Actions quality workflow
- Docker production image

## Requirements

- Node.js 20.9 or newer
- npm 10 or newer

## Local development

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Production verification

```bash
npm run check
```

## Docker

```bash
docker build -t prefab-platform .
docker run --rm -p 3000:3000 prefab-platform
```

## Repository setup

Copy the project files into the empty `prefab-platform` repository and run:

```bash
git add .
git commit -m "feat: create PREFAB.LV foundation"
git branch -M main
git push -u origin main
```

## Current scope

The contact form and login screen are visual foundations. Backend submission, authentication and multilingual routing are intentionally deferred to later sprints.
