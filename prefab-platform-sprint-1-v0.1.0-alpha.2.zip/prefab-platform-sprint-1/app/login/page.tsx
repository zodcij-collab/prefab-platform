import Link from "next/link";

export default function LoginPage() {
  return (
    <main className="login-page">
      <section className="login-card">
        <Link className="login-brand" href="/">PREFAB<span>.LV</span></Link>
        <p className="eyebrow">CORPORATE PORTAL</p>
        <h1>Ienākt sistēmā</h1>
        <form>
          <label>E-pasts<input type="email" placeholder="name@prefab.lv" /></label>
          <label>Parole<input type="password" placeholder="••••••••" /></label>
          <button className="button primary" type="submit">Ienākt</button>
        </form>
        <p className="login-note">Autorizācija tiks pieslēgta nākamajā izstrādes posmā.</p>
      </section>
    </main>
  );
}
