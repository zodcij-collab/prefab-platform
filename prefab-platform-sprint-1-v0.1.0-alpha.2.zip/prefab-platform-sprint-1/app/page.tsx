import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";

const services = [
  ["01", "Saliekamo konstrukciju montāža", "Sienu paneļi, pārseguma plātnes, kāpnes, balkoni un parapeti."],
  ["02", "Betona darbi", "Šuvju aizpildīšana, monolītie mezgli, betonēšana un virsmu apstrāde."],
  ["03", "Metāla konstrukcijas", "Montāža, metināšana un savienojumu izpilde atbilstoši projektam."],
  ["04", "Darbu organizēšana", "Montāžas secība, piegāžu koordinēšana, kvalitātes un drošības kontrole."],
] as const;

export default function HomePage() {
  return (
    <>
      <Header />
      <main id="top">
        <section className="hero">
          <div className="container hero-grid">
            <div className="hero-copy">
              <p className="eyebrow">PREFAB.LV · RĪGA · EIROPĀ</p>
              <h1>Precizitāte saliekamajā būvniecībā.</h1>
              <p className="lead">
                Saliekamo dzelzsbetona konstrukciju montāža, betona darbi un metāla konstrukciju montāža Latvijā un Eiropā.
              </p>
              <div className="hero-actions">
                <a className="button primary" href="#contact">Saņemt piedāvājumu</a>
                <a className="button secondary" href="#projects">Skatīt projektus</a>
              </div>
            </div>
            <div className="hero-visual" aria-label="Saliekamo konstrukciju montāžas vizuālais bloks">
              <div className="structure-lines" />
              <span className="visual-label">ENGINEERED<br />TO FIT.</span>
            </div>
          </div>
        </section>

        <section className="metrics" aria-label="Uzņēmuma galvenie rādītāji">
          <div className="container metrics-grid">
            <div><strong>20+</strong><span>gadu pieredze būvniecībā</span></div>
            <div><strong>50+</strong><span>liela mēroga projekti</span></div>
            <div><strong>EU</strong><span>pieredze Eiropas tirgū</span></div>
            <div><strong>S3</strong><span>drošība ikdienas darbā</span></div>
          </div>
        </section>

        <section className="section" id="company">
          <div className="container split-grid">
            <div>
              <p className="eyebrow">PAR PREFAB.LV</p>
              <h2>Kārtība procesā. Precizitāte montāžā.</h2>
            </div>
            <div className="body-copy">
              <p>
                PREFAB.LV organizē un veic saliekamo dzelzsbetona elementu montāžu, betonēšanas, metināšanas un stropēšanas darbus. Mūsu darba pamatā ir skaidra montāžas secība, kvalificēta komanda un kontrolējams rezultāts.
              </p>
              <p>
                Strādājam ar iekšējām un ārējām sienām, dobajām pārseguma plātnēm, kāpņu, balkonu un parapetu elementiem.
              </p>
            </div>
          </div>
        </section>

        <section className="section surface" id="services">
          <div className="container">
            <div className="section-heading">
              <p className="eyebrow">PAKALPOJUMI</p>
              <h2>No piegādes secības līdz gatavam mezglam.</h2>
            </div>
            <div className="service-list">
              {services.map(([number, title, text]) => (
                <article className="service-row" key={number}>
                  <span>{number}</span>
                  <h3>{title}</h3>
                  <p>{text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section" id="projects">
          <div className="container">
            <div className="section-heading compact">
              <p className="eyebrow">PROJEKTI</p>
              <h2>Pieredze, kuru var pārbaudīt objektā.</h2>
            </div>
            <div className="project-grid">
              <article className="project-card project-large"><span>DAUDZDZĪVOKĻU ĒKAS</span><strong>Saliekamā dzelzsbetona montāža</strong></article>
              <article className="project-card"><span>KOMERCOBJEKTI</span><strong>Konstrukcijas un betona darbi</strong></article>
              <article className="project-card"><span>EIROPAS PROJEKTI</span><strong>Komandas un montāžas vadība</strong></article>
            </div>
          </div>
        </section>

        <section className="section dark" id="careers">
          <div className="container split-grid align-center">
            <div>
              <p className="eyebrow light">KARJERA</p>
              <h2>Pievienojies komandai, kas prot būvēt.</h2>
            </div>
            <div className="body-copy light-copy">
              <p>Meklējam betonētājus, galdniekus, stropētājus, metinātājus un saliekamo konstrukciju montāžas speciālistus.</p>
              <a className="button light-button" href="#contact">Pieteikties darbam</a>
            </div>
          </div>
        </section>

        <section className="section" id="contact">
          <div className="container contact-grid">
            <div>
              <p className="eyebrow">KONTAKTI</p>
              <h2>Sāksim ar sarunu par jūsu projektu.</h2>
              <p className="lead small">Nosūtiet īsu informāciju par objektu, darbu apjomu un plānoto sākumu.</p>
            </div>
            <form className="contact-form">
              <label>Vārds un uzņēmums<input name="name" type="text" placeholder="Jūsu vārds" /></label>
              <label>E-pasts<input name="email" type="email" placeholder="name@company.lv" /></label>
              <label>Tālrunis<input name="phone" type="tel" placeholder="+371" /></label>
              <label>Ziņa<textarea name="message" rows={4} placeholder="Īss projekta apraksts" /></label>
              <button className="button primary" type="submit">Nosūtīt pieprasījumu</button>
            </form>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
