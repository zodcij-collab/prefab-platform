"use client";

import Image from "next/image";
import { useState } from "react";

const links = [
  ["Par mums", "#company"],
  ["Pakalpojumi", "#services"],
  ["Projekti", "#projects"],
  ["Karjera", "#careers"],
  ["Kontakti", "#contact"],
] as const;

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="site-header">
      <div className="container header-inner">
        <a className="brand" href="#top" aria-label="PREFAB.LV sākums">
          <Image src="/brand/prefab-logo.png" alt="PREFAB.LV" width={190} height={116} priority />
        </a>

        <button
          className="menu-button"
          type="button"
          aria-expanded={open}
          aria-controls="main-navigation"
          onClick={() => setOpen((value) => !value)}
        >
          <span />
          <span />
          <span />
          <span className="sr-only">Atvērt izvēlni</span>
        </button>

        <nav id="main-navigation" className={open ? "navigation open" : "navigation"}>
          {links.map(([label, href]) => (
            <a key={href} href={href} onClick={() => setOpen(false)}>
              {label}
            </a>
          ))}
          <a className="login-link" href="/login">Ienākt</a>
          <div className="languages" aria-label="Valodas">
            <button className="active" type="button">LV</button>
            <button type="button">RU</button>
            <button type="button">EN</button>
          </div>
        </nav>
      </div>
    </header>
  );
}
