export function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <strong className="footer-brand">PREFAB<span>.LV</span></strong>
          <p>Saliekamo dzelzsbetona konstrukciju montāža un betona darbi.</p>
        </div>
        <div>
          <h3>Kontakti</h3>
          <a href="tel:+37129446034">+371 29 446 034</a>
          <a href="mailto:edvards@teamprefabtec.eu">edvards@teamprefabtec.eu</a>
          <p>Pērnavas iela 30, Rīga</p>
        </div>
        <div>
          <h3>Uzņēmums</h3>
          <a href="#company">Par mums</a>
          <a href="#services">Pakalpojumi</a>
          <a href="#projects">Projekti</a>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© {new Date().getFullYear()} PREFAB.LV SIA</span>
        <span>Reg. Nr. 40003009726</span>
      </div>
    </footer>
  );
}
