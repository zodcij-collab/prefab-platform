# Changelog

## [0.1.0-alpha.2] - 2026-08-06

### Added

- Automated GitHub quality workflow.
- SEO metadata, robots and sitemap.
- Custom 404 page.
- Node.js engine requirement and combined verification command.

### Changed

- Updated the application stack to Next.js 16.2.12, React 19.2.8 and TypeScript 7.0.2.
- Replaced the legacy Next.js lint command with ESLint flat configuration.
- Expanded local, production and Docker instructions.

## [0.1.0-alpha.1] - 2026-08-06

### Added

- Initial responsive corporate homepage.
- Mobile navigation.
- PREFAB.LV logo asset.
- Login placeholder page.
- Docker production configuration.
